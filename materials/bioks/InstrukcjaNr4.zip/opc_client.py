import sys
sys.path.insert(0, "..")
from opcua import Client
import time
import DateTime

print(DateTime.DateTime.Date())

if __name__ == "__main__":
    client = Client("opc.tcp://localhost:5840/freeopcua/server/")

    try:
        client.connect()

        # Client has a few methods to get proxy to UA nodes that
        #  should always be in address space such as Root or Objects
        root = client.get_root_node()
        print("Objects node is: ", root)

        # Node objects have methods to read and write node attributes
        #  as well as browse or populate address space
        print("Children of root are: ", root.get_children())

        # Now getting a variable node using its browse path
        myvar = root.get_child(["0:Objects", "2:MyObject", "2:MyVariable"])
        myvar1 = root.get_child(["0:Objects", "2:MyObject", "2:MyVariable2"])
        myvar2 = root.get_child(["0:Objects", "2:MyObject", "2:MyVariable3"])
        obj = root.get_child(["0:Objects", "2:MyObject"])

        print("myvar is: ", myvar)
        print("myvar is: ", myvar1)
        print("myvar is: ", myvar2)
        print("myobj is: ", obj)
        while True:
            print(myvar.get_value())
            print(myvar1.get_value())
            print(myvar2.get_value())
            time.sleep(1)

    finally:
        client.disconnect()