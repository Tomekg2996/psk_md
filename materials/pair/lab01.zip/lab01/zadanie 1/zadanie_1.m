clc;        % czyści okno komend
clear all;  % usuwa wszystkie zmienne z workspace

a = 1.3;    % przypisanie wartości zmiennej a
b = 0.9;    % przypisanie wartości zmiennej b

% --- WYRAŻENIE 1 ---
% Obliczamy ln( ∛a + ∜b − 1 ), czyli logarytm naturalny
% kolejno: pierwiastek trzeciego stopnia z a, czwartego stopnia z b,
% suma i odjęcie 1, na końcu log()
result_1 = log(a^(1 / 3) + b^(1 / 4) - 1);
fprintf('Wyrażenie 1: %.6f\n', result_1)    %wyswietlanie wartosci


% --- WYRAŻENIE 2 ---
% cos(pi/3) — kosinus z pi/3 (czyli 60°)
% sin(21°) — funkcja sin w MATLAB przyjmuje argument w radianach,
%            dlatego 21° zamieniamy na radiany funkcją deg2rad()
% atan(0.3)^2 — pierwiastek odwrotny tangensa z 0.3 podniesiony do kwadratu
result_2 = cos(pi/3) + sin(deg2rad(21)) + atan(0.3)^2;
fprintf('Wyrażenie 2: %.6f\n', result_2)    %wyswietlanie wartosci

% --- WYRAŻENIE 3 ---
% Obliczamy: sqrt( sin(0.6) / e^(arccos(0.7)) )
% sin(0.6) — argument w radianach
% exp(acos(0.7)) — e^(arccos(0.7)), znowu arccos zwraca radiany
% całość podnosimy do potęgi 1/2 czyli pierwiastek kwadratowy
result_3 = (sin(0.6) / exp(acos(0.7)))^(1 / 2);
fprintf('Wyrażenie 3: %.6f\n', result_3)    %wyswietlanie wartosci