clc;
clear all;

%% 1) Tworzenie wektora v0 i wektorów pochodnych v1…v4
disp("Punkt 1")
v0 = 0 : 0.5 : 2.5     % wektor poziomy 6-elementowy od 0 do 2.5

disp("Punkt 2")
v1 = v0 + 1            % dodanie 1 do każdego elementu
v2 = v0 - 2            % odjęcie 2
v3 = v0 * 3            % mnożenie przez 3
v4 = v0 / 4            % dzielenie przez 4

%% 2) Konkatenacja wierszy do macierzy A (5x6)
disp("Punkt 3")
A = [v0; v1; v2; v3; v4]
sizeA = size(A);        % rozmiar macierzy (powinien być 5x6)

%% 3) Wyciągnięcie 4-tej kolumny jako wektor Y i usunięcie jej z A
disp("Punkt 4")
Y = A(:, 4)            % Y — wektor kolumnowy z 4-tej kolumny
A(:, 4) = []           % usunięcie tej kolumny → A ma teraz rozmiar 5x5

%% 4) Losowa macierz R i mnożenie element-po-elemencie
disp("Punkt 5")
R = rand(5, 5)         % macierz 5x5 rozkład jednostajny (0,1)
disp("Punkt 6")
A = A .* R             % przemnożenie elementowe A.*R

%% 5) SPOSÓB 1 — jawne utworzenie D1…D5 (bez pętli)
disp("Punkt 7 - rozwiązanie 1")
D1 = A;  
D1(:,1) = Y

D2 = A;  
D2(:,2) = Y

D3 = A;  
D3(:,3) = Y

D4 = A;  
D4(:,4) = Y

D5 = A;  
D5(:,5) = Y

disp("Punkt 8 - rozwiązanie 1")
d1 = [det(D1), det(D2), det(D3), det(D4), det(D5)]   % wyznaczniki
disp("Punkt 9 - rozwiązanie 1")
w1 = d1 / det(A)                                     % wektor w1

%% 6) SPOSÓB 2 — to samo zrobione pętlą i tablicą komórkową
disp("Punkt 7 - rozwiązanie 2")
D = cell(1,5);                % komórki na 5 macierzy
for k = 1:5
    D{k} = A;                 % kopia A
    D{k}(:,k) = Y;            % podstawienie Y w kolumnę k
    disp(D{k})
end

disp("Punkt 8 - rozwiązanie 2")
d2 = [det(D{1}), det(D{2}), det(D{3}), det(D{4}), det(D{5})]   % wyznaczniki
disp("Punkt 9 - rozwiązanie 2")
w2 = d2 / det(A)                                               % wektor w2

%% 7) Rozwiązanie układu A*r = Y metodą A\Y
disp("Punkt 10")
r = A \ Y

%% 8) Porównanie wyników
disp("Punkt 11")
isequal(w1, r)     % zwykle false przez dokładność double,
                   % ale w1 i r powinny być bardzo bliskie numerycznie
