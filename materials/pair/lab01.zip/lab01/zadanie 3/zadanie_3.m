clc;
clear all;

%% 1) Siatka punktów czasu t z krokiem 0.1 w przedziale [0, 12]
t = 0 : 0.1 : 12;

%% 2) Definicje funkcji:
% y1(t) = sin(t) * e^(-0.08 t)
% y2(t) = cos(t) * e^(-0.15 t)
% Uwaga: '.*' to mnożenie element-po-elemencie wektora.
y1_t = sin(t) .* exp(-0.08 * t);
y2_t = cos(t) .* exp(-0.15 * t);

%% 3) Rysowanie obu wykresów w jednym oknie:
figure(1); clf;                          % nowe/wyczyszczone okno
plot(t, y1_t, 'r-', 'LineWidth', 1.5);   % y1: linia ciągła czerwona
hold on;
plot(t, y2_t, 'b--', 'LineWidth', 1.5);  % y2: linia przerywana niebieska
hold off;
grid on;

%% 4) Opisy osi, tytuł, legenda (wewnątrz, centralnie u góry)
xlabel('t');
ylabel('y(t)');
title('Funkcje tłumione: y_1(t)=sin(t)e^{-0.08t},  y_2(t)=cos(t)e^{-0.15t}');
legend({'y_1(t)', 'y_2(t)'}, 'Location', 'north');  % 'north' = wewnątrz, na górze

%% 5) Zapis wykresu do PNG o rozdzielczości 150 dpi
% W nowszych wersjach MATLAB polecany jest exportgraphics:
exportgraphics(gcf, 'zadanie3_wykres_funkcji.png', 'Resolution', 150);
