clc;
clear all;

%% 1) Zakresy argumentów x, y z krokiem 0.25 w przedziale [-4, 4]
x = -4 : 0.25 : 4;
y = -4 : 0.25 : 4;

%% 2) Definicja funkcji Ackleya (zgodnie z podanym wzorem)
% Uwaga: .* i .^ — operacje elementowe dla macierzy
f = @(x, y) -20 * exp(-2 * sqrt(0.5 * (x.^2 + y.^2))) ...
            - exp(0.5 * cos(2 * pi * y)) + 20 + exp(1);

%% 3) Utworzenie siatki punktów dla rysowania 3D
[X, Y] = meshgrid(x, y);  % tworzy macierze X,Y dla wszystkich kombinacji
F = f(X, Y);              % obliczenie wartości funkcji na siatce

%% 4) Rysowanie wykresu 3D
figure(1); clf;
mesh(X, Y, F);            % wykres siatkowy 3D
xlabel('x');
ylabel('y');              
zlabel('f(x, y)');
title('Funkcja Ackleya 3D');

%% 5) Zapis wykresu do pliku PNG z rozdzielczością 150 dpi
exportgraphics(gcf, 'zadanie_4_wykres_funkcji_Ackleya.png', 'Resolution', 150);
