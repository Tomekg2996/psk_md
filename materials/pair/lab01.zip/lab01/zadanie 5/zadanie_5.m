%% =================== ROZWIĄZANIE 1 — SKRYPT ====================
clc;
clear all;

N = 1e6;              % liczba wyrazów sumy (np. 1 000 000)
S = 0;                % akumulator sumy

for i = 0:N
    S = S + (-1)^i/(2*i + 1);   % dodawanie kolejnych wyrazów szeregu
end

pi_est_script = 4*S;               % przybliżenie pi ze skryptu
fprintf('--- SKRYPT ---\n');
fprintf('pi ≈ %.10f   (N=%d)\n', pi_est_script, N);


%% =================== ROZWIĄZANIE 2 — FUNKCJA ====================
% Wywołanie funkcji z dołu tego samego pliku (patrz definicja niżej)
pi_est_fun = pi_leibniz(N);
fprintf('--- FUNKCJA ---\n');
fprintf('pi ≈ %.10f   (N=%d)\n', pi_est_fun, N);


%% =================== FUNKCJA: pi przy użyciu szeregu Leibniza ===
function val = pi_leibniz(N)
    % Funkcja zwraca przybliżenie liczby pi
    % na podstawie sumy Leibniza z N+1 wyrazów
    S = 0;
    for k = 0:N
        S = S + (-1)^k/(2*k + 1);
    end
    val = 4*S;
end
