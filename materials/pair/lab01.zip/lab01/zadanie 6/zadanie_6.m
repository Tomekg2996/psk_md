clc; 
clear;

%% Węzły aproksymacji w [-pi, pi] co pi/10
t = -pi : pi/10 : pi;

%% ====== COS(t) — aproksymacja wielomianem kwadratowym ======
% Model z tabeli: y = a1*t.^2 + a2*t + a0
Yc = cos(t);                  % funkcja aproksymowana
Xc = [t.^2; t; t.^0];         % macierz projektująca (2. wiersz z tabeli)
Ac = Yc / Xc;                 % współczynniki LS (row vector 1x3); równoważne Yc*pinv(Xc)
Yc_hat = Ac * Xc;             % wartości aproksymujące w węzłach

%% Wykres porównawczy dla cos(t)
figure(1); 
clf;
plot(t, Yc, 'b*--', 'LineWidth', 1.5); 
hold on;     % oryginał

plot(t, Yc_hat, 'r-', 'LineWidth', 1.5); 
hold off;  % aproksymacja
grid on; 

xlim([-pi pi]);
xlabel('t'); 
ylabel('y');
title('Aproksymacja {\it cos}(t) wielomianem: a_1 t^2 + a_2 t + a_0');
legend('cos(t)', 'aproksymacja', 'Location', 'best');
fprintf('COS: max|błąd| = %.3e\n', max(abs(Yc - Yc_hat)));

exportgraphics(gcf, 'zadanie_6.png', 'Resolution', 150);
