clc; 
clear;

%% Dane tabelaryczne
X = [0 30 60 90 120 150 180];
Y = [140.00 131.67 123.24 134.70 146.06 157.32 168.47];

%% --- Tworzymy macierz projektującą jak w tabeli: [x.^2; x; x.^0]
M = [X.^2; X; X.^0];

%% --- Wyznaczenie współczynników LS (dokładnie jak Y / X w zadaniu 6)
A = Y / M;                % współczynniki a1,a2,a0

%% --- Wartości funkcji aproksymującej w węzłach
Ya = A * M;

%% --- Rysunek
xx = linspace(min(X),max(X),400);
Mf = [xx.^2; xx; xx.^0];
Yf = A * Mf;

figure(1); clf;
plot(X,Y,'ko','MarkerFaceColor','w');   % punkty tabelaryczne
hold on;     
plot(xx,Yf,'r-','LineWidth',1.5);       % krzywa aproksymacji 
hold off;         
grid on;
xlabel('X');
ylabel('Y');
title('Aproksymacja danych wielomianem kwadratowym');
legend('dane','aproksymacja','Location','best');

%% --- Zapis wykresu
exportgraphics(gcf,'zadanie_7.png','Resolution',150);
