import numpy as np
import imageio.v3 as imageio
import matplotlib.pyplot as plt

# Wczytaj obraz w skali szarości
image = imageio.imread('image.png', mode='L')  # lub podaj ścieżkę do własnego obrazu

# Definicja maski 3x3 (filtr wyostrzający)
kernel = np.array([[ 0, -1, 0],
                   [ -1, 5, -1],
                   [ 0, -1, 0]])


# Funkcja do wykonania konwolucji
def filter(image, kernel, padding='reflect'):
    h, w = image.shape
    kh, kw = kernel.shape
    ph, pw = kh // 2, kw // 2
    
    
    # Dopełnienie obrazu
    padded = np.pad(image, ((ph, ph), (pw, pw)), mode=padding)
    output = np.zeros_like(image)
    
    for i in range(h):
        for j in range(w):
            region = padded[i:i+kh, j:j+kw]
            value = np.sum(region * kernel)
            output[i, j] = np.clip(value, 0, 255)
    
    return output

# Zastosuj filtr
filtered_image = filter(image, kernel)

# Wyświetl wyniki
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(image, cmap='gray')
plt.title('Oryginalny obraz')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(filtered_image, cmap='gray')
plt.title('Po filtracji (wyostrzanie)')
plt.axis('off')

plt.tight_layout()
plt.show()
